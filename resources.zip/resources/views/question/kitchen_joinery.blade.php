  <div class="pdf-header">
      <h2>11) radio & JOINERY</h2>
  </div>
  <div class="card pdf-card mb-3">
      <div class="card-header d-flex justify-content-between align-items-center">

          <h5>11.1 radio
          </h5>
      </div>
      <div class="card-body">

          <div class="form-group row">
              <div class="col-sm-12">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][radio_fixed_price]"
                          id="radio_fixed_price" value="fixed" checked>
                      <label class="form-check-label" for="radio_fixed_price">If by builder: 1) Fixed price included in
                          quote</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][radio_fixed_price]"
                          id="radio_provisional_sum" value="provisional">
                      <label class="form-check-label" for="radio_provisional_sum">Or 2) Provisional Sum</label>
                  </div>
                  <img src="https://via.placeholder.com/150x30?text=Amount+to+be+shown+at+Section+16+'Schedule+of+Provisional+Sums'"
                      alt="Provisional Sum Note">
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- radio manufacturer:</label>
              <div class="col-sm-9">
                  <input type="text" name="sow[radio_and_joinery][radio_manufacturer]" class="form-control"
                      value="PRESTIGE">
                  <small class="form-text text-muted">Manufacturer's Name</small>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- radio layout plan attached:</label>
              <div class="col-sm-9">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][radio_layout_plan]"
                          id="radio_layout_yes" value="yes" checked>
                      <label class="form-check-label" for="radio_layout_yes">Yes</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][radio_layout_plan]"
                          id="radio_layout_no" value="no">
                      <label class="form-check-label" for="radio_layout_no">No</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- Appliances: Note: See "PC Selections" section</label>
              <div class="col-sm-9">
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][appliances_supply_fit]"
                          id="appliances_supply_fit" value="supply_fit">
                      <label class="form-check-label" for="appliances_supply_fit">Supply & fit by radio
                          manufacturer</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- Sink supply:</label>
              <div class="col-sm-9">
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][sink_supply_only]"
                          id="sink_supply_only" value="supply_only" checked>
                      <label class="form-check-label" for="sink_supply_only">Supply only by builder</label>
                  </div>
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][sink_by_others]"
                          id="sink_by_others" value="by_others">
                      <label class="form-check-label" for="sink_by_others">By others:</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">Range hood installation:</label>
              <div class="col-sm-9">
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][range_hood_builder]"
                          id="range_hood_builder" value="by_builder" checked>
                      <label class="form-check-label" for="range_hood_builder">By builder</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label"></label>
              <div class="col-sm-9">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio"
                          name="sow[radio_and_joinery][range_hood_recirculated]" id="range_hood_recirculated"
                          value="recirculated">
                      <label class="form-check-label" for="range_hood_recirculated">Re-circulated into room</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][range_hood_vented]"
                          id="range_hood_vented" value="vented" checked>
                      <label class="form-check-label" for="range_hood_vented">Vented to atmosphere</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- Bulkheads to overhead cupboards required:</label>
              <div class="col-sm-9">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][bulkheads_required]"
                          id="bulkheads_required_yes" value="yes" checked>
                      <label class="form-check-label" for="bulkheads_required_yes">Yes</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][bulkheads_required]"
                          id="bulkheads_required_or" value="or">
                      <label class="form-check-label" for="bulkheads_required_or">OR</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][bulkheads_required]"
                          id="bulkheads_required_na" value="na">
                      <label class="form-check-label" for="bulkheads_required_na">N/A</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][bulkheads_by]"
                          id="bulkheads_by_plasterer" value="plasterer">
                      <label class="form-check-label" for="bulkheads_by_plasterer">By plasterer</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][bulkheads_by]"
                          id="bulkheads_by_radio" value="radio" checked>
                      <label class="form-check-label" for="bulkheads_by_radio">By radio manufacturer</label>
                  </div>
              </div>
          </div>

          <div class="form-group">
              <label>Notes to above:</label>
              <textarea name="sow[radio_and_joinery][radio_notes]"
                  class="form-control">UNIT ONE BEIGE TONES UNIT TWO BLACK WHITE</textarea>
          </div>
      </div>
  </div>

  <div class="card pdf-card mb-3">
      <div class="card-header d-flex justify-content-between align-items-center">
          <h5>11.2 Vanity Units
          </h5>
          <div class="radiobuttons-wrap">

              <label class="form-check-label" for="vanity_pc_selections">Per PC Selections <input
                      class="form-check-input" type="radio" name="sow[radio_and_joinery][vanity_pc_selections]"
                      id="vanity_pc_selections" value="pc_selections" checked></label>

              <label class="form-check-label" for="vanity_by_owner">By Owner <input class="form-check-input"
                      type="radio" name="sow[radio_and_joinery][vanity_by_owner]" id="vanity_by_owner"
                      value="by_owner"></label>
          </div>
      </div>

      <div class="card-body">

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- Vanity Supply:</label>
              <div class="col-sm-9">
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][vanity_supply]"
                          id="standard_vanity" value="standard" checked>
                      <label class="form-check-label" for="standard_vanity">Standard vanity units selected from retail
                          supplier (See PC Selections)</label>
                  </div>
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][vanity_supply]"
                          id="custom_vanity" value="custom">
                      <label class="form-check-label" for="custom_vanity">Custom made vanity/s by radio
                          manufacturer</label>
                  </div>
              </div>
          </div>
          <div class="d-flex align-items-center">
              <!-- Label and Input -->
              <label for="vanity_units" class="me-2 mb-0">Notes to above:</label>
              <input type="text" class="form-control form-control-sm w-75 border-0 border-bottom"
                  name="sow[site_work][vanity_units]" id="vanity_units" placeholder="Enter vanity units notes">
          </div>
      </div>
  </div>



  <div class="card pdf-card mb-3">
      <div class="card-header d-flex justify-content-between align-items-center">
          <h5>11.3 Laundry Tub/Units
          </h5>
          <div class="radiobuttons-wrap">

              <label class="form-check-label" for="laundry_pc_selections">Per PC Selections <input
                      class="form-check-input" type="radio" name="sow[radio_and_joinery][laundry_pc_selections]"
                      id="laundry_pc_selections" value="pc_selections" checked></label>

              <label class="form-check-label" for="laundry_by_owner">By Owner <input class="form-check-input"
                      type="radio" name="sow[radio_and_joinery][laundry_pc_selections]" id="laundry_by_owner"
                      value="by_owner"></label>
          </div>
      </div>

      <div class="card-body">

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">- Tub Supply:</label>
              <div class="col-sm-9">
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][tub_supply_builder]"
                          id="tub_supply_builder" value="builder" checked>
                      <label class="form-check-label" for="tub_supply_builder">Tub supply only by Builder (See PC
                          Selections)</label>
                  </div>
                  <div class="form-check">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][tub_supply_builder]"
                          id="tub_supply_custom" value="custom">
                      <label class="form-check-label" for="tub_supply_custom">Custom made unit by radio
                          manufacturer</label>
                  </div>

              </div>
          </div>
          <div class="d-flex align-items-center">
              <label for="laundry_tub" class="me-2 mb-0">Notes to above:</label>
              <input type="text" class="form-control form-control-sm w-75 border-0 border-bottom"
                  name="sow[site_work][laundry_tub]" id="laundry_tub" placeholder="Enter  laundry tub/unitsg notes">
          </div>
      </div>
  </div>

  <div class="card pdf-card mb-3">
      <div class="card-header d-flex justify-content-between align-items-center">
          <h5>11.4 Shelving</h5>
          <div class="radiobuttons-wrap">

              <label class="form-check-label" for="shelving_additional">Additional Non Standard <input
                      class="form-check-input" type="radio" name="sow[radio_and_joinery][shelving_additional]"
                      id="shelving_additional" value="additional"></label>

              <label class="form-check-label" for="shelving_na">N/A <input class="form-check-input" type="radio"
                      name="sow[radio_and_joinery][shelving_na]" id="shelving_na" value="na" checked></label>
          </div>
      </div>
      <div class="card-body">

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">Shelving Manufacturer:</label>
              <div class="col-sm-9">
                  <input type="text" name="shelving_manufacturer" class="form-control">
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">Non standard shelving by others shown on plan:</label>
              <div class="col-sm-9">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][shelving_by_others]"
                          id="shelving_by_others_yes" value="yes">
                      <label class="form-check-label" for="shelving_by_others_yes">Yes</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][shelving_by_others]"
                          id="shelving_by_others_no" value="no">
                      <label class="form-check-label" for="shelving_by_others_no">No</label>
                  </div>
              </div>
          </div>
          <div class="d-flex align-items-center">
              <!-- Label and Input -->
              <label for="shelving" class="me-2 mb-0">Notes to above:</label>
              <input type="text" class="form-control form-control-sm w-75 border-0 border-bottom"
                  name="sow[site_work][shelving]" id="shelving" placeholder="Enter  shelving notes">
          </div>
      </div>
  </div>


  <div class="card pdf-card mb-3">
      <div class="card-header d-flex justify-content-between align-items-center">
          <h5>11.5 Staircases & Balustrades (Internal)
          </h5>
          <div class="radiobuttons-wrap">

              <label class="form-check-label" for="staircase_selections">Per Selections & Plans <input
                      class="form-check-input" type="radio" name="sow[radio_and_joinery][staircase_selections]"
                      id="staircase_selections" value="selections" checked></label>

              <label class="form-check-label" for="staircase_na">N/A <input class="form-check-input" type="radio"
                      name="sow[radio_and_joinery][staircase_na]" id="staircase_na" value="na"></label>
          </div>
      </div>

      <div class="card-body">
          <div class="font-weight-bold mb-2">Staircase</div>

          <div class="form-group row">
              <div class="col-sm-12">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][staircase_fixed_price]"
                          id="staircase_fixed_price" value="fixed_price">
                      <label class="form-check-label" for="staircase_fixed_price">Fixed Price included in Quote</label>
                  </div>
                  <div class="form-check form-check-inline">

                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][staircase_fixed_price]"
                          id="staircase_fixed_price" value="provisional_sum">
                      <label class="form-check-label" for="staircase_fixed_price">Provisional Sum</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">Manufacturer's Name:</label>
              <div class="col-sm-9">
                  <input type="text" name="sow[radio_and_joinery][staircase_manufacturer]" class="form-control">
              </div>
          </div>



          <div class="font-weight-bold mb-2">Balustrade</div>

          <div class="form-group row">
              <div class="col-sm-12">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][balustrade_fixed_price]"
                          id="balustrade_fixed_price" value="fixed_price">
                      <label class="form-check-label" for="balustrade_fixed_price">Fixed Price included in Quote</label>
                  </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="sow[radio_and_joinery][balustrade_fixed_price]"
                          id="balustrade_fixed_price" value="provisional_sum">
                      <label class="form-check-label" for="balustrade_fixed_price">Provisional Sum</label>
                  </div>
              </div>
          </div>

          <div class="form-group row">
              <label class="col-sm-3 col-form-label">Manufacturer's Name:</label>
              <div class="col-sm-9">
                  <input type="text" name="sow[radio_and_joinery][balustrade_manufacturer]" class="form-control">
              </div>
          </div>

          <div class="d-flex align-items-center">
              <!-- Label and Input -->
              <label for="manufacturer_note" class="me-2 mb-0">Notes to above:</label>
              <input type="text" class="form-control form-control-sm w-75 border-0 border-bottom"
                  name="sow[site_work][manufacturer_note]" id="manufacturer_note" placeholder="Manufacturer Note">
          </div>

          <div class="form-group">
              <label>Notes to above:</label>
              <div class="form-check">
                  <input class="form-check-input" type="radio" name="sow[radio_and_joinery][special_fixing_checked]"
                      id="special_fixing_checked" value="checked">
                  <label class="form-check-label" for="special_fixing_checked">
                      <strong>Note 1:</strong> Special fixing points or blocking may be required. This should be checked
                      with the manufacturer before wall and ceiling linings are installed.
                  </label>
              </div>
              <div class="form-check">

                  <strong>Note 2:</strong> Beadings and trimming off, if required, will be charged as an extra.
                  (Staircase
                  supplier/installer should generally supply and install all necessary moldings required to trim off the
                  staircase to linings).
                  </label>
              </div>
          </div>
          <div class="d-flex align-items-center">
              <!-- Label and Input -->
              <label for="staircases_balustrades" class="me-2 mb-0">Notes to above:</label>
              <input type="text" class="form-control form-control-sm w-75 border-0 border-bottom"
                  name="sow[site_work][staircases_balustrades]" id="staircases_balustrades"
                  placeholder="Enter Staircases & Balustrades (Internal) notes">
          </div>
      </div>
  </div>