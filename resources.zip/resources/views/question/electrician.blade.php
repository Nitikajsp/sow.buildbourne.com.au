<div class="pdf-header">
    <h2>9) ELECTRICIAN</h2>
</div>
<div class="card pdf-card mb-3">
    <div class="card-header d-flex justify-content-between align-items-center">

        <h5>9.1 Power into property</h5>

        <div class="radiobuttons-wrap">
            <!-- <div class="form-check form-check-inline"> -->

            <label class="me-3" for="by_builder">By Builder <input class="form-check-input" type="radio"
                    name="sow[electrician][power_into_property]" id="by_builder" value="by_builder" checked></label>
            <!-- </div>
        <div class="form-check form-check-inline"> -->

            <label class="me-3" for="by_owner">By Owner <input class="form-check-input" type="radio"
                    name="sow[electrician][power_into_property]" id="by_owner" value="by_owner"></label>
            <!-- </div>
        <div class="form-check form-check-inline"> -->
            <label class="me-3" for="na">N/A <input class="form-check-input" type="radio"
                    name="sow[electrician][power_into_property]" id="na" value="na">
            </label>
            <!-- </div> -->
        </div>
    </div>


    <div class="card-body">

        <div class="form-group row">
            <div class="col-sm-12">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][power_into_property_price]"
                        id="fixed_10mtrs" value="fixed_10mtrs" checked>
                    <label class="form-check-label" for="fixed_10mtrs">If by builder: 1) Fixed price included in quote
                        up to
                        10 mtr's</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][power_into_property_price]"
                        id="fixed_plan" value="fixed_plan">
                    <label class="form-check-label" for="fixed_plan">2) Fixed price included in quote as per
                        plan's</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][power_into_property_price]"
                        id="provisional_sum" value="provisional_sum">
                    <label class="form-check-label" for="provisional_sum">Or 3) Provisional Sum</label>
                </div>
            </div>
        </div>


        <div class="d-flex align-items-center mt-3">
            <!-- Label and Input -->
            <label for="power_into_property" class="me-2 mb-0  flex-shrink-0 ">Notes to above:</label>
            <input type="text" class="form-control form-control-sm border-0 border-bottom"
                name="sow[site_work][power_into_property]" id="power_into_property"
                placeholder="Enter power into property notes">
        </div>
    </div>
</div>


<div class="card pdf-card mb-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>9.2 Connection to Dwelling</h5>
    </div>
    <div class="card-body">

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">- Service provider connection fee:</label>
            <div class="col-sm-9">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][service_provider_fee]"
                        id="provisional_sum_fee" value="provisional_sum">
                    <label class="form-check-label" for="provisional_sum_fee">Provisional Sum</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][service_provider_fee]"
                        id="fixed_builder" value="fixed_builder" checked>
                    <label class="form-check-label" for="fixed_builder">Fixed price by builder</label>
                </div>

            </div>

        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">- Connection type:</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="sow[electrician][connection_type]"
                    id="connection_type" value="by_owner">
                <label class="form-check-label" for="connection_type">By owner</label>
            </div>
            <div class="col-sm-9">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][connection_type]"
                        id="provisional_sum_type" value="provisional_sum">
                    <label class="form-check-label" for="provisional_sum_type">Provisional Sum</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][connection_type]"
                        id="fixed_builder_type" value="fixed_builder" checked>
                    <label class="form-check-label" for="fixed_builder_type">Fixed price by builder</label>
                </div>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][underground]" id="underground"
                        value="underground">
                    <label class="form-check-label" for="underground">Underground</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board]"
                        id="existing_sub_board" value="existing_sub_board">
                    <label class="form-check-label" for="existing_sub_board">From existing sub board</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board]"
                        id="existing_sub_board" value="existing_meter_box">
                    <label class="form-check-label" for="existing_sub_board">From existing meter box</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board]"
                        id="existing_sub_board" value="public_main_dwelling">
                    <label class="form-check-label" for="existing_sub_board">Public main to dwelling</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][aerial]" id="aerial"
                        value="aerial" checked>
                    <label class="form-check-label" for="aerial">Aerial</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board_pole]"
                        id="existing_sub_board_pole" value="existing_sub_board_pole">
                    <label class="form-check-label" for="existing_sub_board_pole">From existing sub board or meter box
                        on
                        pole</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board_pole]"
                        id="public_main_dwelling_aerial" value="public_main_dwelling_aerial" checked>
                    <label class="form-check-label" for="existing_sub_board_pole">Public main to dwelling</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board_pole]"
                        id="existing_sub_board_pole" value="public_private_aerial">
                    <label class="form-check-label" for="public_private_aerial">Public main to private pole/s then
                        aerial to
                        dwelling</label>
                </div>
                <div class="form-check ml-4">
                    <input class="form-check-input" type="radio" name="sow[electrician][existing_sub_board_pole]"
                        id="existing_sub_board_pole" value="public_private_underground">
                    <label class="form-check-label" for="public_private_underground">Public main to private pole/s then
                        underground to dwelling</label>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">- Metering:</label>
            <div class="col-sm-9">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][metering]" id="meter_box_pole"
                        value="meter_box_pole">
                    <label class="form-check-label" for="meter_box_pole">Meter box on pole or other structure - sub
                        board to
                        dwelling</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][metering]"
                        id="meter_box_dwelling" value="meter_box_dwelling" checked>
                    <label class="form-check-label" for="meter_box_dwelling">Meter box to dwelling</label>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">- Show preferred position on Electrical Plan of:</label>
            <div class="col-sm-9">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][electrical_plan_position]"
                        id="meter_box_sub_board" value="meter_box_sub_board">
                    <label class="form-check-label" for="meter_box_sub_board">Meter box or sub board</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][electrical_plan_position]"
                        id="aerial_point" value="aerial_point" checked>
                    <label class="form-check-label" for="aerial_point">Aerial point of attachment (if
                        applicable)</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio"
                        name="sow[electrician][electrical_plan_position_checked]" id="checked" value="checked" checked>
                    <label class="form-check-label" for="checked">Checked</label>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Notes to above:</label>
            <div class="col-sm-9">
                <p>
                    Note1: Aerial consumer mains connection up to 10 Metres is standard and included. Underground mains
                    connection & or distances over 10 Metres will be at an extra cost unless otherwise stated. A
                    Provisional
                    Sum if agreed will provide an allowance amount for the works. Cost of work over the allowance
                    charged at
                    cost plus margin on the sum over, or a credit given if within allowance.
                </p>
                <p>
                    Note2: Power provider mains should be checked to ensure adequate supply is available to the
                    dwelling.
                    For example - Three phase power may be required for Air Conditioning, Rural Availability, and
                    Transformer Availability & Size.
                </p>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sow[electrician][provider_checked]"
                        id="provider_checked" value="provider_checked">
                    <label class="form-check-label" for="provider_checked">(Checked with Provider)</label>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <!-- Label and Input -->
            <label for="connection_to_dwelling" class="me-2 mb-0  flex-shrink-0 ">Notes to above:</label>
            <input type="text" class="form-control form-control-sm border-0 border-bottom"
                name="sow[site_work][connection_to_dwelling]" id="connection_to_dwelling"
                placeholder="Enter  connection to dwelling notes">
        </div>
    </div>
</div>



<div class="card pdf-card mb-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>9.3 Electrical Wiring
        </h5>
        <div class="radiobuttons-wrap">

            <label class="form-check-label" for="by_builder">By Builder <input class="form-check-input" type="radio"
                    name="sow[electrician][by_builder]" id="by_builder" value="by_builder" checked></label>

            <label class="form-check-label" for="by_owner">By Owner <input class="form-check-input" type="radio"
                    name="sow[electrician][by_builder]" id="by_owner" value="by_owner"></label>
        </div>
    </div>



    <div class="card-body">
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">- If by builder: 1) Fixed price included in quote</label>
            <div class="col-sm-9">
                <input type="radio" class="form-check-input" name="sow[electrician][fixed_price_quote]"
                    id="fixed_price_quote" value="fixed_price_quote">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">SEE LAYOUTS</label>
            <div class="col-sm-9">
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Power points internal</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][power_points_internal]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Power points External Weatherproof Qty</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][power_points_external]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Light Points Internal</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][light_points_internal]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Light Points External</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][light_points_external]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">2 Way Light Switches</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][light_switches_2way]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Ceiling Fans</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][ceiling_fans]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Exhaust Fans</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][exhaust_fans]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Phone Points</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][phone_points]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Television Points</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][television_points]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Internet Points</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][internet_points]" class="form-control"
                            placeholder="Qty =">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Smoke Detectors</label>
                    <div class="col-sm-6">
                        <input type="text" name="sow[electrician][smoke_detectors]" class="form-control"
                            placeholder="Qty =">
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-6 col-form-label">Fluco Garage Lights</label>
                        <div class="col-sm-6">
                            <input type="text" name="sow[electrician][fluco_garage_lights]" class="form-control"
                                placeholder="Qty =">
                        </div>
                        <div class="form-group row">

                            <div class="col-sm-9">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label>Electrical Layout Plans:</label><br>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][electrical_layout_plans]"
                                                    id="electrical_layout_plans_yes"
                                                    value="As per electrical layout plans, completed & signed by owners">
                                                <label class="form-check-label" for="electrical_layout_plans_yes">As per
                                                    electrical layout plans, completed & signed by owners</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][electrical_layout_plans]"
                                                    id="electrical_layout_plans_na" value="N/A">
                                                <label class="form-check-label"
                                                    for="electrical_layout_plans_na">N/A</label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Kitchen Layout Plans:</label><br>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][kitchen_layout_plans]"
                                                    id="kitchen_layout_plans_yes"
                                                    value="As per kitchen manufacturer's layout plan provided">
                                                <label class="form-check-label" for="kitchen_layout_plans_yes">As per
                                                    kitchen manufacturer's layout plan provided</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][kitchen_layout_plans]"
                                                    id="kitchen_layout_plans_na" value="N/A">
                                                <label class="form-check-label"
                                                    for="kitchen_layout_plans_na">N/A</label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Plumbing Layout Plans:</label><br>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][plumbing_layout_plans]"
                                                    id="plumbing_layout_plans_yes"
                                                    value="As per plumbing & drainage layout plan (showing locations of hot water service, pumps etc)">
                                                <label class="form-check-label" for="plumbing_layout_plans_yes">As per
                                                    plumbing & drainage layout plan</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][plumbing_layout_plans]"
                                                    id="plumbing_layout_plans_na" value="N/A">
                                                <label class="form-check-label"
                                                    for="plumbing_layout_plans_na">N/A</label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>PC Selections:</label><br>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][pc_selections]" id="pc_selections_yes"
                                                    value="As per PC selections">
                                                <label class="form-check-label" for="pc_selections_yes">As per PC
                                                    selections</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][pc_selections]" id="pc_selections_na"
                                                    value="N/A">
                                                <label class="form-check-label" for="pc_selections_na">N/A</label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Provisional Sum:</label><br>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="sow[electrician][provisional_sum_pc_selections]"
                                                    id="provisional_sum" value="Provisional Sum">
                                                <label class="form-check-label" for="provisional_sum">Provisional
                                                    Sum</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-muted mb-3">
                                <strong>Note 1:</strong> Unless otherwise specified herein all light fittings (with the
                                exception of garage fluro lights) including ceiling fans are to be purchased by the
                                owner
                                and provided when requested by the electrician for installation. If not provided as
                                requested batten holders only will be fitted.
                            </div>

                            <div class="text-muted mb-3">
                                <strong>Note 2:</strong> Power supply to pumps and septic system is included up to a
                                distance of 10 Metres. Distances over 10 Metres will be charge as an extra at cost plus
                                builders margin. Extra Standard Internal lights will be charged at $60.00 each, extra
                                internal double power points will be charged at $60.00 each and extra external power
                                points
                                will be charged at $100.00 each.
                            </div>

                            <div class="text-muted mb-3">
                                <strong>Note 3:</strong> Appliance's to be installed which may require special wiring
                                (eg 15
                                amp outlets for dryers or pumps, Hot water services with twin elements or boosters for
                                solar
                                and cook tops which require an extra phase) should have installation requirements
                                attached
                                from the manufacturer or list special requirements below
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="sow[electrician][checked]"
                                        id="checked" value="checked">
                                    <label class="form-check-label" for="checked">(Checked)</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Special requirements:</label>
                                <textarea name="sow[electrician][checked]" class="form-control"></textarea>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">- Power Supply to Waste Water System
                                    (Septic)</label>
                                <div class="col-sm-8">
                                    <input type="text" name="sow[electrician][power_supply_waste_water]"
                                        class="form-control mb-2" value="Position Shown on Plans">
                                    <input type="text" name="sow[electrician][length_run_system]" class="form-control"
                                        value="Length of run to system (max 15m)">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Optimum Air <br>See Quote <br>Air
                                    conditioning</label>
                                <div class="col-sm-8">
                                    <input type="text" name="sow[electrician][air_conditioning_type]"
                                        class="form-control mb-2" value="Type SPLIT SYSTEM">
                                    <input type="text" name="sow[electrician][air_conditioning_supply]"
                                        class="form-control mb-2" value="Supply required">
                                    <input type="text" name="sow[electrician][air_conditioning_position]"
                                        class="form-control" value="Position Shown on Electrical Plan">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">- Indicate specific items on Plan:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="sow[electrician][specific_items_plan]" class="form-control"
                                        value="Type & Supply required">
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Other items</label>
                                <input type="text" name="sow[electrician][other_items]" class="form-control"
                                    value="Positions shown on Electrical Plan">
                            </div>

                            <div class="form-group">
                                <label>- Light Switch's & Power Points</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio"
                                        name="sow[electrician][light_switch_type]" id="standard_white"
                                        value="standard_white">
                                    <label class="form-check-label" for="standard_white">Standard White</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio"
                                        name="sow[electrician][light_switch_type]" id="other" value="other">
                                    <label class="form-check-label" for="other">Other</label>
                                </div>
                                <input type="text" name="sow[electrician][light_switch_manufacturer]"
                                    class="form-control mb-2" placeholder="Manufacturer:">
                                <input type="text" name="sow[electrician][light_switch_type_text]"
                                    class="form-control mb-2" placeholder="Type:">
                                <input type="text" name="sow[electrician][light_switch_pn]" class="form-control"
                                    placeholder="Style or P/N:">
                            </div>

                            <div class="text-muted mb-3">
                                <strong>Note 4:</strong> Light Fittings other than standard batten holders are to be
                                supplied by the owner prior to final fit out. The cost of assembly and fitting of lights
                                and
                                fans will be charged as an extra being cost plus builder's margin and GST.
                            </div>

                            <div class="text-muted mb-3">
                                <strong>Note 5:</strong> No allowance has been made in the event of rock excavation and
                                the
                                resultant extra construction time. Any rock excavation and extra construction time
                                required
                                will be charged at an hourly rate of builder's cost plus builder's margin and GST. This
                                rate
                                will be inclusive of both labour and equipment hire.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <!-- Label and Input -->
                    <label for="electrical wiring" class="me-2 mb-0  flex-shrink-0 ">Notes to above:</label>
                    <input type="text" class="form-control form-control-sm border-0 border-bottom"
                        name="sow[site_work][electrical wiring]" id="electrical wiring"
                        placeholder="Enter  electrical wiring notes">
                </div>
            </div>
        </div>
    </div>